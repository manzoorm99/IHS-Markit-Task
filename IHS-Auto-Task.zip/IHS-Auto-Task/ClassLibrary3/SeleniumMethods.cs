﻿using System;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using IHS.PageObjects;
using NUnit.Framework;
using PageObjects;
using OpenQA.Selenium;

namespace IHS.Core
{
    public class SeleniumMethods
    {
        private static IWebDriver driver;
        private static WebDriverWait Wait;

        public static void Init(String baseURL)
        {
            driver = new ChromeDriver();
            driver.Navigate().GoToUrl(baseURL + "/");
            Wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
        }

        public static void RunButton()
        {
         //Test 1://
            IWebElement Runbutton = driver.FindElement(By.Id(ClickRunButton.RunBtnID));
            Runbutton.Click();
            Wait.Until(d => d.FindElement(By.Id(ClickRunButton.RunBtnID)));
            //driver.FindElement(By.Id(ClickRunButton.outputpaneID)).Click();
            Assert.AreEqual(driver.FindElement(By.Id(ClickRunButton.outputID)).Text,Is.EqualTo("Hello World"));
        }

        public static void SelectnugetPackege()
        {
         //Test 2 (If your first name starts with letter “A-B-C-D-E”): //

            IWebElement NugetPackege = driver.FindElement(By.CssSelector(SelectNugetPackages.NugetID));
            NugetPackege.Click();
            Wait.Until(d => d.FindElement(By.CssSelector(SelectNugetPackages.NugetID)));
            NugetPackege.Clear();
            NugetPackege.SendKeys("nUnit(3.12.0)");
            NugetPackege.SendKeys(Keys.Enter);
        }

        // Test 2 (If your first name starts with letter “F-G-H-I-J-K”): //
        public static void ShareBtn()
        {
            IWebElement Sharebtn = driver.FindElement(By.Id(ClickShareButton.ShareBtnID));
            Sharebtn.Click();
            Assert.AreEqual(driver.FindElement(By.Id(ClickShareButton.ShareLink)).Text,Is.EqualTo("https://dotnetfiddle.net/"));
        }

        //Test 2 (If your first name starts with letter “L-M-N-O-P”)://

        public static void PanelBtn()
        {
            IWebElement panelbtn = driver.FindElement(By.CssSelector(ClickPanelButton.PanelID));
            panelbtn.Click();
            var elements = driver.FindElements(By.CssSelector(ClickPanelButton.Hiddenpanel));
            Assert.True(elements.Count == 0);
        }

        public static void SaveBtn()
        {
         // Test 2 (If your first name starts with letter “Q-R-S-T-U”)://
            IWebElement savebtn = driver.FindElement(By.Id(ClickSaveButton.SaveID));
            savebtn.Click();
            Wait.Until(d => d.FindElement(By.CssSelector(ClickSaveButton.SaveID)));
            Assert.AreEqual(driver.FindElement(By.Id(ClickSaveButton.LoginPage)).Text,Is.EqualTo("Login"));
        }

        //Test 2 (If your first name starts with letter “V-W-X-Y-Z”)://

        public static void GettingstartedBtn()
        {
            IWebElement GstartedBtn = driver.FindElement(By.Id(ClickGettingStartedButton.GettingStartedBtnID));
            GstartedBtn.Click();

            Wait.Until(d => d.FindElement(By.CssSelector(ClickGettingStartedButton.GettingStartedBtnID)));
            Assert.AreEqual(driver.FindElement(By.Id(ClickGettingStartedButton.BackEditorBtn)).Text, Is.EqualTo("Back to Editor"));
        }
        public static void Quit()
        {
            driver.Quit();
            driver.Dispose();


        }
    }
}

