﻿using System;

namespace IHS.Core
{
    public class Class1
    {
    }
}
