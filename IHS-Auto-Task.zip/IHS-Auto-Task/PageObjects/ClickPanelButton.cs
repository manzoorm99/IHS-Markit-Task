﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Test 2 (If your first name starts with letter “L-M-N-O-P”)://

namespace IHS.PageObjects
{
    public class ClickPanelButton
    {
        public static string PanelID
        {
            get
            {
                return ".btn-sidebar-toggle > .glyphicon";
            }
        }

        public static string Hiddenpanel
        {
            get
            {
                return ".expander";
            }
        }
    }

}


