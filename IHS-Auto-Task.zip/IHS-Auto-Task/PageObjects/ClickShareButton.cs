﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Test 2 (If your first name starts with letter “F-G-H-I-J-K”): //

namespace IHS.PageObjects
{
   public class ClickShareButton
    {
        public static string ShareBtnID
        {
            get
            {
                return "Share";
            }
        }

            public static string ShareLink
        {
            get
            {
                return "ShareLink";
            }
        }
    }
}
