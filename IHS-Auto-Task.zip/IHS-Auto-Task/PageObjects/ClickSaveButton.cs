﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Test 2 (If your first name starts with letter “Q-R-S-T-U”)://
namespace PageObjects
{
    public class ClickSaveButton
    {
        public static string SaveID
        {
            get
            {
                return "save-button";
            }
        }

        public static string LoginPage
        {
            get
            {
                return "login-modal-label";
            }
        }
    }
}

