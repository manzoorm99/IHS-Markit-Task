﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IHS.PageObjects
{
    public class ClickGettingStartedButton
    {
        public static string GettingStartedBtnID
        {
            get
            {
                return "Getting Started";
            }
        }
        public static string BackEditorBtn
        {
            get
            {
                return "Back To Editor";
            }
        }
    }
}
