﻿using OpenQA.Selenium.Remote;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
//using System.Selenium.Support.PageObjects;


namespace IHS.PageObjects
//Test1//
{
    public class ClickRunButton
    {
        public static string RunBtnID
        {
            get
            {
                return "run-button";
            }
        }
        public static string outputpaneID
        {
            get
            {
                return "output";
            }
        }
        public static string outputID
        {
            get
            {
                return "output";
            }

        }
    }
}


