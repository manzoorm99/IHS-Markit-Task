﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IHS.PageObjects
//Test 2 (If your first name starts with letter “A-B-C-D-E”): //
{
    public class SelectNugetPackages
    {
        public static string NugetID
        {
            get
            {
                return ".new-package";
            }
        }
    }
}
