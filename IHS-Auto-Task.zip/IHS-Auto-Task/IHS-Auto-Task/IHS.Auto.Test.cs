﻿using NUnit.Framework;
using IHS.Core;
using System.Text;

namespace IHS_Auto_Task
{
    [TestFixture]

    public class AutoTestClass
    {
    private string baseURL;

    [OneTimeSetUp]

    public void SetupTest()
        {
            baseURL = "https://dotnetfiddle.net/";
            SeleniumMethods.Init(baseURL);
        }

     [Test]

     public void TheIHSTest()
        {
            SeleniumMethods.RunButton();
            SeleniumMethods.SelectnugetPackege();
            SeleniumMethods.PanelBtn();
            SeleniumMethods.SaveBtn();
            SeleniumMethods.GettingstartedBtn();
        }

    [TearDown]

    public void TeardownTest()
        {
            SeleniumMethods.Quit();
        }
    }
}
